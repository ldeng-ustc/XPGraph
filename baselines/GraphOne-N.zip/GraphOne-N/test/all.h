#pragma once
#include <vector>

using std::vector;

#include "graph.h"

#include "sgraph.h"
#include "sgraph2.h"
/*----------- labels ------------------ */
//#include "labelkv.h"
#include "typekv.h"
#include "stringkv.h"
#include "numberkv.h"
#include "str2sid.h"


